
DROP INDEX idx_robot_conversations_created_at;
DROP INDEX idx_robot_conversations_user_id;
DROP TABLE robot_conversations;
