
CREATE TABLE robot_conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  message TEXT NOT NULL,
  is_from_user BOOLEAN NOT NULL,
  message_type TEXT DEFAULT 'chat',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_robot_conversations_user_id ON robot_conversations(user_id);
CREATE INDEX idx_robot_conversations_created_at ON robot_conversations(created_at);
