
ALTER TABLE tasks DROP COLUMN reminder_time;
