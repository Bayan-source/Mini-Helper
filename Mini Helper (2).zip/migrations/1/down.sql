
DROP INDEX idx_tasks_created_at;
DROP INDEX idx_tasks_user_id;
DROP TABLE tasks;
