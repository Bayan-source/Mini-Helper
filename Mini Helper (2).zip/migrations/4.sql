
ALTER TABLE tasks ADD COLUMN reminder_time DATETIME;
