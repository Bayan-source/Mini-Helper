
DROP INDEX idx_expenses_created_at;
DROP INDEX idx_expenses_user_id;
DROP TABLE expenses;
