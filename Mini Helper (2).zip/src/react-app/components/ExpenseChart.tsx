import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";
import { ExpenseType } from "@/shared/types";

interface ExpenseChartProps {
  expenses: ExpenseType[];
}

const COLORS = [
  "#10b981", // emerald-500
  "#059669", // emerald-600
  "#047857", // emerald-700
  "#065f46", // emerald-800
  "#064e3b", // emerald-900
  "#6ee7b7", // emerald-300
  "#34d399", // emerald-400
  "#a7f3d0", // emerald-200
];

export default function ExpenseChart({ expenses }: ExpenseChartProps) {
  // Group expenses by category
  const categoryData = expenses.reduce((acc, expense) => {
    const category = expense.category || "Other";
    if (acc[category]) {
      acc[category] += expense.amount;
    } else {
      acc[category] = expense.amount;
    }
    return acc;
  }, {} as Record<string, number>);

  // Convert to chart data
  const chartData = Object.entries(categoryData).map(([category, amount]) => ({
    name: category,
    value: amount,
  }));

  // If there's only one category or very few expenses, show a simple bar
  if (chartData.length <= 1) {
    return (
      <div className="space-y-2">
        {chartData.map((item) => (
          <div key={item.name} className="flex items-center justify-between">
            <span className="text-sm text-gray-600">{item.name}</span>
            <div className="flex items-center gap-2">
              <div 
                className="h-2 bg-emerald-500 rounded"
                style={{ width: '100px' }}
              />
              <span className="text-sm font-medium">${item.value.toFixed(2)}</span>
            </div>
          </div>
        ))}
      </div>
    );
  }

  const renderLabel = (props: any) => {
    const { name, percent } = props;
    return `${name}: ${(percent * 100).toFixed(0)}%`;
  };

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={renderLabel}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
          >
            {chartData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
