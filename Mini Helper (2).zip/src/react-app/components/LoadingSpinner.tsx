import { Bot } from "lucide-react";

interface LoadingSpinnerProps {
  message?: string;
}

export default function LoadingSpinner({ message = "Loading..." }: LoadingSpinnerProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <div className="animate-bounce mb-4">
        <Bot className="w-12 h-12 text-emerald-600" />
      </div>
      <p className="text-gray-600 text-lg">{message}</p>
    </div>
  );
}
