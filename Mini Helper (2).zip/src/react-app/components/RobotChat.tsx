import { useState, useEffect, useRef } from "react";
import { Send, Bot, User } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import { RobotConversationType } from "@/shared/types";

export default function RobotChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<RobotConversationType[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchMessages();
    }
  }, [user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchMessages = async () => {
    if (!user) return;
    
    try {
      const response = await fetch("/api/chat", {
        credentials: 'include'
      });
      if (response.ok) {
        const messagesData = await response.json();
        setMessages(messagesData);
      } else {
        console.error("Failed to fetch messages:", response.status);
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || isSending || !user) return;

    try {
      setIsSending(true);
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: 'include',
        body: JSON.stringify({
          message: newMessage,
        }),
      });

      if (response.ok) {
        setNewMessage("");
        await fetchMessages();
      } else {
        console.error("Failed to send message:", response.status);
      }
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-96">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-4 pr-2">
        {messages.length === 0 ? (
          <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-2xl">
            <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-gray-800">Hello! I'm Mini, your helper for today 😊</p>
              <p className="text-sm text-gray-600 mt-1">Ask me anything or tell me what you need help with!</p>
            </div>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start gap-3 ${
                message.is_from_user ? "justify-end" : ""
              }`}
            >
              {!message.is_from_user && (
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] p-3 rounded-2xl ${
                  message.is_from_user
                    ? "bg-blue-500 text-white rounded-br-md"
                    : "bg-emerald-50 text-gray-800 rounded-bl-md"
                }`}
              >
                <p>{message.message}</p>
              </div>
              {message.is_from_user && (
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={user ? "Ask Mini anything..." : "Please log in to chat with Mini..."}
          className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
          disabled={isSending || !user}
        />
        <button
          onClick={sendMessage}
          disabled={isSending || !newMessage.trim() || !user}
          className="p-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
