import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import TasksPage from "@/react-app/pages/Tasks";
import ExpensesPage from "@/react-app/pages/Expenses";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-sky-100 via-sky-200 to-sky-300">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/expenses" element={<ExpensesPage />} />
            <Route path="/auth/callback" element={<AuthCallbackPage />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}
