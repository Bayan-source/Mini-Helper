import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Bot, CheckSquare, DollarSign, LogOut } from "lucide-react";
import RobotChat from "@/react-app/components/RobotChat";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";

export default function Home() {
  const { user, isPending, redirectToLogin, logout } = useAuth();
  const navigate = useNavigate();

  if (isPending) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 text-center max-w-md w-full">
          <div className="mb-6">
            <Bot className="w-20 h-20 mx-auto text-emerald-600 mb-4" />
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Mini Helper</h1>
            <p className="text-gray-600">Your cute robot assistant for daily tasks and expenses</p>
          </div>
          <button
            onClick={redirectToLogin}
            className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            Get Started with Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <Bot className="w-10 h-10 text-emerald-600" />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Mini Helper</h1>
              <p className="text-gray-600">Hey {user.google_user_data.given_name || user.email}! 👋</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="hidden md:inline">Logout</span>
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Welcome Section */}
          <div className="space-y-6">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center">
                  <Bot className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Hello! I'm Mini, your helper for today 😊</h2>
                  <p className="text-gray-600">Let's get organized and stay on track!</p>
                </div>
              </div>

              <div className="grid gap-4">
                <button
                  onClick={() => navigate("/tasks")}
                  className="flex items-center gap-3 bg-gradient-to-r from-emerald-700 to-emerald-800 text-white font-semibold py-4 px-6 rounded-xl hover:from-emerald-800 hover:to-emerald-900 transition-all duration-200 transform hover:scale-105 shadow-lg"
                >
                  <CheckSquare className="w-6 h-6" />
                  <span>Add Task</span>
                </button>

                <button
                  onClick={() => navigate("/expenses")}
                  className="flex items-center gap-3 bg-gradient-to-r from-emerald-400 to-emerald-500 text-gray-900 font-semibold py-4 px-6 rounded-xl hover:from-emerald-500 hover:to-emerald-600 transition-all duration-200 transform hover:scale-105 shadow-lg"
                >
                  <DollarSign className="w-6 h-6" />
                  <span>Add Expense</span>
                </button>
              </div>
            </div>
          </div>

          {/* Robot Chat Section */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Bot className="w-6 h-6 text-emerald-600" />
              Chat with Mini
            </h3>
            <RobotChat />
          </div>
        </div>
      </div>
    </div>
  );
}
