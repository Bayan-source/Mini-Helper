import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";

export default function AuthCallback() {
  const { exchangeCodeForSessionToken } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        await exchangeCodeForSessionToken();
        navigate("/");
      } catch (error) {
        console.error("Auth callback error:", error);
        navigate("/");
      }
    };

    handleAuthCallback();
  }, [exchangeCodeForSessionToken, navigate]);

  return <LoadingSpinner message="Setting up your account..." />;
}
