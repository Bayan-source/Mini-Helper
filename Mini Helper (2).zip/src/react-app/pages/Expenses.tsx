import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, DollarSign } from "lucide-react";
import { ExpenseType } from "@/shared/types";
import ExpenseChart from "@/react-app/components/ExpenseChart";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";

export default function Expenses() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [expenses, setExpenses] = useState<ExpenseType[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingExpense, setIsAddingExpense] = useState(false);
  const [newExpenseTitle, setNewExpenseTitle] = useState("");
  const [newExpenseAmount, setNewExpenseAmount] = useState("");
  const [newExpenseCategory, setNewExpenseCategory] = useState("");

  useEffect(() => {
    if (user) {
      fetchExpenses();
    }
  }, [user]);

  const fetchExpenses = async () => {
    try {
      const response = await fetch("/api/expenses");
      if (response.ok) {
        const expensesData = await response.json();
        setExpenses(expensesData);
      }
    } catch (error) {
      console.error("Error fetching expenses:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const addExpense = async () => {
    if (!newExpenseTitle.trim() || !newExpenseAmount || parseFloat(newExpenseAmount) <= 0) return;

    try {
      setIsAddingExpense(true);
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: newExpenseTitle,
          amount: parseFloat(newExpenseAmount),
          category: newExpenseCategory || undefined,
        }),
      });

      if (response.ok) {
        setNewExpenseTitle("");
        setNewExpenseAmount("");
        setNewExpenseCategory("");
        await fetchExpenses();
      }
    } catch (error) {
      console.error("Error adding expense:", error);
    } finally {
      setIsAddingExpense(false);
    }
  };

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  if (isPending || !user) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-white/20 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-3xl font-bold text-gray-800">My Expenses</h1>
        </div>

        {/* Add Expense Form */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Add New Expense</h2>
          <div className="grid md:grid-cols-3 gap-4 mb-4">
            <input
              type="text"
              value={newExpenseTitle}
              onChange={(e) => setNewExpenseTitle(e.target.value)}
              placeholder="Enter your expense here..."
              className="px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
            />
            <input
              type="number"
              value={newExpenseAmount}
              onChange={(e) => setNewExpenseAmount(e.target.value)}
              placeholder="Amount ($)"
              step="0.01"
              min="0"
              className="px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
            />
            <input
              type="text"
              value={newExpenseCategory}
              onChange={(e) => setNewExpenseCategory(e.target.value)}
              placeholder="Category (optional)"
              className="px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
            />
          </div>
          <button
            onClick={addExpense}
            disabled={isAddingExpense || !newExpenseTitle.trim() || !newExpenseAmount || parseFloat(newExpenseAmount) <= 0}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-400 to-emerald-500 text-gray-900 font-semibold py-3 px-6 rounded-xl hover:from-emerald-500 hover:to-emerald-600 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-5 h-5" />
            {isAddingExpense ? "Adding..." : "Add New Expense"}
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Expenses Chart */}
          {expenses.length > 0 && (
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Spending Overview</h2>
              <div className="mb-4">
                <p className="text-2xl font-bold text-emerald-600">
                  ${totalExpenses.toFixed(2)}
                </p>
                <p className="text-gray-600">Total spent</p>
              </div>
              <ExpenseChart expenses={expenses} />
            </div>
          )}

          {/* Expenses List */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Recent Expenses</h2>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
              </div>
            ) : expenses.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-600">No expenses yet! Add one above to start tracking. 💰</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {expenses.map((expense) => (
                  <div
                    key={expense.id}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-gray-900" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{expense.title}</h3>
                        {expense.category && (
                          <p className="text-sm text-gray-700">{expense.category}</p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-900">${expense.amount.toFixed(2)}</p>
                      <p className="text-xs text-gray-700">
                        {new Date(expense.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
