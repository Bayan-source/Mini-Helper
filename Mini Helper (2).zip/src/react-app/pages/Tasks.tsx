import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Check, Bell, BellOff } from "lucide-react";
import { TaskType } from "@/shared/types";
import LoadingSpinner from "@/react-app/components/LoadingSpinner";

export default function Tasks() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<TaskType[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const [newTaskReminderTime, setNewTaskReminderTime] = useState("");

  useEffect(() => {
    if (user) {
      fetchTasks();
      
      // Check for reminders every minute
      const interval = setInterval(() => {
        checkReminders();
      }, 60000);

      // Check immediately on mount
      checkReminders();

      return () => clearInterval(interval);
    }
  }, [user]);

  const checkReminders = () => {
    const now = new Date();
    tasks.forEach(task => {
      if (task.reminder_time && !task.is_completed) {
        const reminderTime = new Date(task.reminder_time);
        const timeDiff = reminderTime.getTime() - now.getTime();
        
        // Show notification if reminder is within 1 minute
        if (timeDiff > 0 && timeDiff <= 60000) {
          if (Notification.permission === "granted") {
            new Notification("تذكير بالمهمة - Task Reminder", {
              body: task.title,
              icon: "https://mocha-cdn.com/favicon.ico"
            });
          }
        }
      }
    });
  };

  useEffect(() => {
    // Request notification permission on mount
    if (Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await fetch("/api/tasks");
      if (response.ok) {
        const tasksData = await response.json();
        setTasks(tasksData);
      }
    } catch (error) {
      console.error("Error fetching tasks:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const addTask = async () => {
    if (!newTaskTitle.trim()) return;

    try {
      setIsAddingTask(true);
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: newTaskTitle,
          description: newTaskDescription,
          reminder_time: newTaskReminderTime || undefined,
        }),
      });

      if (response.ok) {
        setNewTaskTitle("");
        setNewTaskDescription("");
        setNewTaskReminderTime("");
        await fetchTasks();
      }
    } catch (error) {
      console.error("Error adding task:", error);
    } finally {
      setIsAddingTask(false);
    }
  };

  const toggleTask = async (taskId: number, currentStatus: boolean) => {
    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          is_completed: !currentStatus,
        }),
      });

      if (response.ok) {
        await fetchTasks();
      }
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const formatReminderTime = (reminderTime: string | null) => {
    if (!reminderTime) return null;
    const date = new Date(reminderTime);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    const timeStr = date.toLocaleTimeString('ar-SA', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
    
    if (isToday) {
      return `اليوم ${timeStr}`;
    } else {
      return date.toLocaleDateString('ar-SA', { 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  };

  if (isPending || !user) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-white/20 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-3xl font-bold text-gray-800">مهامي - My Tasks</h1>
        </div>

        {/* Add Task Form */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">إضافة مهمة جديدة - Add New Task</h2>
          <div className="space-y-4">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="أدخل مهمتك هنا... Enter your task here..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
              onKeyPress={(e) => e.key === "Enter" && !e.shiftKey && addTask()}
            />
            <textarea
              value={newTaskDescription}
              onChange={(e) => setNewTaskDescription(e.target.value)}
              placeholder="أضف وصفاً (اختياري)... Add a description (optional)..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80 resize-none"
              rows={2}
            />
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-emerald-600" />
              <input
                type="datetime-local"
                value={newTaskReminderTime}
                onChange={(e) => setNewTaskReminderTime(e.target.value)}
                className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white/80"
              />
            </div>
            <button
              onClick={addTask}
              disabled={isAddingTask || !newTaskTitle.trim()}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-700 to-emerald-800 text-white font-semibold py-3 px-6 rounded-xl hover:from-emerald-800 hover:to-emerald-900 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="w-5 h-5" />
              {isAddingTask ? "جاري الإضافة... Adding..." : "إضافة مهمة - Add Task"}
            </button>
          </div>
        </div>

        {/* Tasks List */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">مهامك - Your Tasks</h2>
          
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
            </div>
          ) : tasks.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600">لا توجد مهام بعد! أضف واحدة أعلاه للبدء - No tasks yet! Add one above to get started. 😊</p>
            </div>
          ) : (
            <div className="space-y-3">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-200 ${
                    task.is_completed 
                      ? "bg-emerald-50 border border-emerald-200" 
                      : "bg-emerald-700 border border-emerald-800"
                  }`}
                >
                  <button
                    onClick={() => toggleTask(task.id, task.is_completed)}
                    className={`flex items-center justify-center w-6 h-6 rounded-full transition-all duration-200 flex-shrink-0 ${
                      task.is_completed
                        ? "bg-emerald-600 text-white"
                        : "bg-white text-emerald-700 hover:bg-emerald-50"
                    }`}
                  >
                    {task.is_completed ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <div className="w-4 h-4" />
                    )}
                  </button>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className={`font-semibold ${
                      task.is_completed ? "text-emerald-800 line-through" : "text-white"
                    }`}>
                      {task.title}
                    </h3>
                    {task.description && (
                      <p className={`text-sm mt-1 ${
                        task.is_completed ? "text-emerald-600" : "text-emerald-100"
                      }`}>
                        {task.description}
                      </p>
                    )}
                    {task.reminder_time && (
                      <div className={`flex items-center gap-1 mt-2 text-xs ${
                        task.is_completed ? "text-emerald-600" : "text-emerald-200"
                      }`}>
                        <Bell className="w-3 h-3" />
                        <span>{formatReminderTime(task.reminder_time)}</span>
                      </div>
                    )}
                  </div>

                  {task.reminder_time && !task.is_completed && (
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                        <Bell className="w-4 h-4 text-white animate-pulse" />
                      </div>
                    </div>
                  )}
                  
                  {!task.reminder_time && !task.is_completed && (
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                        <BellOff className="w-4 h-4 text-white/50" />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
