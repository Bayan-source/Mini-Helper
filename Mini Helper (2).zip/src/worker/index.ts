import { Hono } from "hono";
import { cors } from "hono/cors";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  getCurrentUser,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import { 
  TaskSchema, 
  CreateTaskSchema, 
  ExpenseSchema, 
  CreateExpenseSchema, 
  RobotConversationSchema,
  ChatMessageSchema 
} from "@/shared/types";
import OpenAI from "openai";

type CustomEnv = {
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
  OPENAI_API_KEY: string;
  DB: D1Database;
}

const app = new Hono<{ Bindings: CustomEnv }>();

app.use("*", cors({
  origin: (origin) => origin || "*",
  credentials: true,
  allowMethods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
}));

// Auth endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
    domain: undefined, // Let browser determine the domain
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", async (c) => {
  try {
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
    
    if (!sessionToken) {
      return c.json({ error: "No session token" }, 401);
    }

    const user = await getCurrentUser(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    if (!user) {
      return c.json({ error: "Invalid session" }, 401);
    }

    return c.json(user);
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
    domain: undefined,
  });

  return c.json({ success: true }, 200);
});

// Tasks endpoints
app.get("/api/tasks", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC"
  ).bind(user.id).all();

  return c.json(results.map(task => TaskSchema.parse({
    ...task,
    is_completed: Boolean(task.is_completed)
  })));
});

app.post("/api/tasks", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const validatedData = CreateTaskSchema.parse(body);

  const result = await c.env.DB.prepare(`
    INSERT INTO tasks (user_id, title, description, reminder_time, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(user.id, validatedData.title, validatedData.description || null, validatedData.reminder_time || null).run();

  // Add robot celebration message
  await c.env.DB.prepare(`
    INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(user.id, "Great! I added that task for you! 🎯 Don't forget to check it off when you're done!", false, "task_added").run();

  return c.json({ id: result.meta.last_row_id, success: true });
});

app.patch("/api/tasks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const taskId = c.req.param("id");
  const body = await c.req.json();

  await c.env.DB.prepare(`
    UPDATE tasks 
    SET is_completed = ?, updated_at = datetime('now')
    WHERE id = ? AND user_id = ?
  `).bind(body.is_completed ? 1 : 0, taskId, user.id).run();

  // Add robot celebration message if task completed
  if (body.is_completed) {
    await c.env.DB.prepare(`
      INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(user.id, "Good job! 🎉 You completed your task! Keep going, you're doing great! 💪", false, "task_completed").run();
  }

  return c.json({ success: true });
});

// Expenses endpoints
app.get("/api/expenses", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM expenses WHERE user_id = ? ORDER BY created_at DESC"
  ).bind(user.id).all();

  return c.json(results.map(expense => ExpenseSchema.parse(expense)));
});

app.post("/api/expenses", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const validatedData = CreateExpenseSchema.parse(body);

  const result = await c.env.DB.prepare(`
    INSERT INTO expenses (user_id, title, amount, category, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(user.id, validatedData.title, validatedData.amount, validatedData.category || null).run();

  // Add robot response message
  await c.env.DB.prepare(`
    INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(user.id, `Got it! I've tracked your expense of $${validatedData.amount.toFixed(2)}. Good job keeping track of your spending! 📊`, false, "expense_added").run();

  return c.json({ id: result.meta.last_row_id, success: true });
});

// Robot chat endpoints
app.get("/api/chat", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM robot_conversations WHERE user_id = ? ORDER BY created_at ASC LIMIT 50"
  ).bind(user.id).all();

  return c.json(results.map(msg => RobotConversationSchema.parse({
    ...msg,
    is_from_user: Boolean(msg.is_from_user)
  })));
});

app.post("/api/chat", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const validatedData = ChatMessageSchema.parse(body);

  // Save user message
  await c.env.DB.prepare(`
    INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
  `).bind(user.id, validatedData.message, true, "chat").run();

  try {
    // Get user's recent tasks and expenses for context
    const { results: tasks } = await c.env.DB.prepare(
      "SELECT title, is_completed, reminder_time FROM tasks WHERE user_id = ? ORDER BY created_at DESC LIMIT 10"
    ).bind(user.id).all();

    const { results: expenses } = await c.env.DB.prepare(
      "SELECT title, amount, category, created_at FROM expenses WHERE user_id = ? ORDER BY created_at DESC LIMIT 10"
    ).bind(user.id).all();

    const { results: expenseStats } = await c.env.DB.prepare(
      "SELECT SUM(amount) as total FROM expenses WHERE user_id = ? AND DATE(created_at) = DATE('now')"
    ).bind(user.id).all();
    const todayTotal = (expenseStats[0] as any)?.total || 0;

    const incompleteTasks = tasks.filter((t: any) => !t.is_completed);
    const completedTasks = tasks.filter((t: any) => t.is_completed);

    // Get conversation history for context
    const { results: history } = await c.env.DB.prepare(
      "SELECT message, is_from_user FROM robot_conversations WHERE user_id = ? ORDER BY created_at DESC LIMIT 10"
    ).bind(user.id).all();

    // Build conversation history for OpenAI (in reverse order)
    const conversationHistory = history.reverse().map((msg: any) => ({
      role: (msg.is_from_user ? "user" : "assistant") as "user" | "assistant",
      content: msg.message as string
    }));

    // Create context about user's data
    const contextInfo = `
User Context:
- Incomplete tasks: ${incompleteTasks.length}
- Completed tasks: ${completedTasks.length}
- Total expenses today: $${todayTotal.toFixed(2)}
- Recent expenses: ${expenses.length > 0 ? expenses.slice(0, 3).map((e: any) => `${e.title} ($${e.amount})`).join(", ") : "None"}
- Recent tasks: ${tasks.length > 0 ? tasks.slice(0, 3).map((t: any) => t.title).join(", ") : "None"}
`;

    // Initialize OpenAI client
    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    // Generate AI response
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are Mini, a cute and helpful robot assistant for a task and expense tracking app called "Mini Helper". You help users manage their daily tasks and track their expenses. You are friendly, encouraging, supportive, and use emojis naturally. You speak both English and Arabic fluently - respond in the same language the user uses.

Your personality:
- Warm and encouraging
- Celebrate user achievements
- Provide helpful reminders
- Be concise but friendly
- Use emojis to add warmth (but not excessively)

${contextInfo}

Keep responses brief (1-3 sentences typically) unless the user asks for detailed information. Be conversational and natural, like a helpful friend.`
        },
        ...conversationHistory.slice(-8), // Keep last 8 messages for context
        {
          role: "user",
          content: validatedData.message
        }
      ],
      temperature: 0.8,
      max_tokens: 200,
    });

    const robotResponse = response.choices[0].message.content || "I'm here to help! Ask me anything about your tasks or expenses. 😊";

    // Save robot response
    await c.env.DB.prepare(`
      INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(user.id, robotResponse, false, "chat").run();

    return c.json({ success: true });
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Fallback response if OpenAI fails
    const fallbackResponse = "I'm here to help you with your tasks and expenses! How can I assist you today? 😊";
    
    await c.env.DB.prepare(`
      INSERT INTO robot_conversations (user_id, message, is_from_user, message_type, created_at, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(user.id, fallbackResponse, false, "chat").run();

    return c.json({ success: true });
  }
});

export default app;
