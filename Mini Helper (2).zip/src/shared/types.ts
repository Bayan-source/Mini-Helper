import z from "zod";

export const TaskSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  is_completed: z.boolean(),
  reminder_time: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTaskSchema = z.object({
  title: z.string().min(1, "Task title is required"),
  description: z.string().optional(),
  reminder_time: z.string().optional(),
});

export const ExpenseSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  title: z.string(),
  amount: z.number(),
  category: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateExpenseSchema = z.object({
  title: z.string().min(1, "Expense title is required"),
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  category: z.string().optional(),
});

export const RobotConversationSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  message: z.string(),
  is_from_user: z.boolean(),
  message_type: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ChatMessageSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
});

export type TaskType = z.infer<typeof TaskSchema>;
export type CreateTaskType = z.infer<typeof CreateTaskSchema>;
export type ExpenseType = z.infer<typeof ExpenseSchema>;
export type CreateExpenseType = z.infer<typeof CreateExpenseSchema>;
export type RobotConversationType = z.infer<typeof RobotConversationSchema>;
export type ChatMessageType = z.infer<typeof ChatMessageSchema>;
